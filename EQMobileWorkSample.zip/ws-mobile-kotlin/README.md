# Work Sample for Mobile Aspect, Kotlin Variant

[What is this for?](https://github.com/EQWorks/work-samples#what-is-this)
